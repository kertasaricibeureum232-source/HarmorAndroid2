# Harmor Android Lab (prototype 0.1)

A native Android/Kotlin starter for an original additive synthesizer inspired by the workflow of FL Studio Harmor. It does not use Image-Line code, samples, graphics, or presets.

## Implemented in this prototype
- Real-time additive oscillator (16 partials)
- Touch piano keys (14 white-key positions)
- Harmonic brightness control
- Three simple starting timbres
- Five-second WAV export to Music/HarmorAndroid

## Planned next milestones
1. Replace the basic view with a full multi-panel harmonic editor and draggable partials.
2. Add proper ADSR pitch/filter/volume envelopes, LFO, and filter DSP.
3. Add resampling of live output and longer user-defined WAV renders.
4. Add Android MIDI input/output (USB/Bluetooth MIDI) and MIDI file import/export.
5. Add preset save/load, polyphony, voice management, anti-aliasing and latency tuning.

## Build APK
Open this folder in Android Studio (Giraffe or newer), let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be under `app/build/outputs/apk/debug/`.

This environment cannot compile/sign an Android APK. The project is supplied as source so it can be built in Android Studio. Test on a real device; audio latency and performance vary by device.
