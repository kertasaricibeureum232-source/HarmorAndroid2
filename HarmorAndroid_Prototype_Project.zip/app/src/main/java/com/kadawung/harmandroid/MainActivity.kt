package com.kadawung.harmandroid

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.widget.*
import android.media.AudioTrack
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioTrack.WRITE_BLOCKING
import android.content.ContentValues
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var synth: Synth
    private lateinit var panel: SynthPanel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        synth = Synth()
        panel = SynthPanel()
        setContentView(panel)
    }
    override fun onDestroy() { synth.stop(); super.onDestroy() }

    inner class SynthPanel : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val keys = mutableListOf<RectF>()
        private val names = listOf("C","D","E","F","G","A","B","C")
        private var harm = 0.45f
        private var attack = 0.02f
        private var release = 0.25f
        private var selected = "Init Saw"
        private var dragging = false
        private var exportRect = RectF()
        private var presetRect = RectF()
        init { isFocusable = true }
        override fun onDraw(c: Canvas) {
            c.drawColor(Color.rgb(16,17,20))
            p.color=Color.rgb(30,32,38); c.drawRoundRect(12f,12f,width-12f,height-12f,18f,18f,p)
            p.color=Color.WHITE; p.textSize=25f; p.typeface=Typeface.create("sans-serif",Typeface.BOLD)
            c.drawText("HARMOR  /  ANDROID LAB",28f,48f,p)
            p.textSize=12f;p.color=Color.LTGRAY;p.typeface=Typeface.DEFAULT
            c.drawText("ADDITIVE SYNTH  •  HARMONICS  •  REAL-TIME AUDIO",29f,69f,p)
            p.color=Color.rgb(245,166,35); c.drawRoundRect(28f,88f,width*.62f, height*.47f,10f,10f,p)
            p.color=Color.rgb(25,27,32); c.drawRoundRect(31f,91f,width*.62f-3,height*.47f-3,8f,8f,p)
            val count=24; val bw=(width*.62f-12)/count
            for(i in 0 until count) {
                val v= if(i==0) harm else (0.12f/(i+1)+harm/(i+1)).coerceIn(0.02f,0.95f)
                p.color=if(i==0) Color.rgb(255,190,70) else Color.rgb(70,180,210)
                val x=37f+i*bw
                c.drawRoundRect(x,height*.44f-v*(height*.27f),x+bw*.65f,height*.44f,3f,3f,p)
            }
            p.color=Color.WHITE;p.textSize=14f;c.drawText("HARMONICS",30f,height*.51f,p)
            p.color=Color.LTGRAY;p.textSize=12f
            c.drawText("Brightness",30f,height*.57f,p)
            p.color=Color.rgb(55,58,66);c.drawRoundRect(120f,height*.545f,width*.58f,height*.575f,8f,8f,p)
            p.color=Color.rgb(245,166,35);c.drawRoundRect(120f,height*.545f,120f+(width*.58f-120f)*harm,height*.575f,8f,8f,p)
            c.drawText("Amp attack  ${(attack*1000).toInt()} ms",30f,height*.64f,p)
            c.drawText("Release  ${(release*1000).toInt()} ms",30f,height*.69f,p)
            presetRect.set(width*.68f,28f,width-28f,72f)
            p.color=Color.rgb(55,61,73);c.drawRoundRect(presetRect,8f,8f,p)
            p.color=Color.WHITE;p.textSize=14f;c.drawText("PRESET: $selected",presetRect.left+12,presetRect.centerY()+5,p)
            exportRect.set(width*.68f,88f,width-28f,132f)
            p.color=Color.rgb(65,110,88);c.drawRoundRect(exportRect,8f,8f,p)
            p.color=Color.WHITE;c.drawText("EXPORT 5s WAV",exportRect.left+12,exportRect.centerY()+5,p)
            p.color=Color.LTGRAY;p.textSize=11f;c.drawText("PITCH / FILTER ENVELOPE (basic)",width*.68f,160f,p)
            c.drawText("Touch keys to play • Hold for sustain",width*.68f,180f,p)
            drawKeyboard(c)
        }
        private fun drawKeyboard(c:Canvas) {
            keys.clear()
            val left=28f; val top=height*.76f; val bottom=height-24f
            val kw=(width-56f)/14f
            for(i in 0 until 14) {
                val r=RectF(left+i*kw,top,left+(i+1)*kw-2,bottom);keys.add(r)
                p.color=Color.rgb(235,237,240);c.drawRoundRect(r,3f,3f,p)
                p.color=Color.DKGRAY;p.textSize=12f;c.drawText(names[i%8],r.left+5,bottom-8,p)
            }
            val black= listOf(0,1,3,4,5,7,8,10,11,12)
            for(i in black) {
                val x=left+(i+1)*kw-kw*.28f
                p.color=Color.rgb(27,29,34);c.drawRoundRect(x,top,x+kw*.56f,top+(bottom-top)*.58f,3f,3f,p)
            }
        }
        override fun onTouchEvent(e:MotionEvent):Boolean {
            val x=e.x; val y=e.y
            when(e.action) {
                MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE -> {
                    if(y>height*.76f) {
                        val idx=((x-28f)/((width-56f)/14f)).toInt().coerceIn(0,13)
                        synth.noteOn(60+idx); return true
                    }
                    if(y in (height*.53f)..(height*.59f)) { harm=((x-120f)/(width*.58f-120f)).coerceIn(0f,1f); synth.brightness=harm; invalidate();return true }
                }
                MotionEvent.ACTION_UP -> {
                    synth.noteOff()
                    if(presetRect.contains(x,y)) {
                        selected=if(selected=="Init Saw") "Soft Pad" else if(selected=="Soft Pad") "Bright Organ" else "Init Saw"
                        synth.preset(selected); invalidate()
                    } else if(exportRect.contains(x,y)) exportWav()
                }
            }; return true
        }
        private fun exportWav() {
            val data=synth.render(5)
            val header=ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray());header.putInt(36+data.size);header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray());header.putInt(16);header.putShort(1);header.putShort(1)
            header.putInt(44100);header.putInt(88200);header.putShort(2);header.putShort(16)
            header.put("data".toByteArray());header.putInt(data.size)
            val values=ContentValues().apply { put(MediaStore.Audio.Media.DISPLAY_NAME,"HarmorAndroid_${System.currentTimeMillis()}.wav");put(MediaStore.Audio.Media.MIME_TYPE,"audio/wav");put(MediaStore.Audio.Media.RELATIVE_PATH,"Music/HarmorAndroid") }
            val uri=contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,values)
            if(uri!=null) contentResolver.openOutputStream(uri)?.use { it.write(header.array());it.write(data) }
            Toast.makeText(this@MainActivity,"WAV tersimpan di Music/HarmorAndroid",Toast.LENGTH_LONG).show()
        }
    }
}

class Synth {
    @Volatile var brightness=0.45f
    @Volatile private var freq=440.0
    @Volatile private var gate=false
    private var phase=0.0
    private var track:AudioTrack?=null
    private var playing=false
    private val sr=44100
    init { start() }
    fun start() {
        val min=AudioTrack.getMinBufferSize(sr,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)
        track=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(min,sr/4)).setTransferMode(AudioTrack.MODE_STREAM).build()
        track?.play(); playing=true
        Thread {
            val buf=ShortArray(512)
            while(playing) {
                for(i in buf.indices) buf[i]=(sample()*12000).toInt().coerceIn(-32768,32767).toShort()
                track?.write(buf,0,buf.size)
            }
        }.apply { name="AdditiveAudio";isDaemon=true;start() }
    }
    @Synchronized private fun sample():Double {
        phase+=2*PI*freq/sr
        if(phase>2*PI) phase-=2*PI
        if(!gate) return 0.0
        var out=0.0
        for(n in 1..16) out+=sin(phase*n)*brightness.toDouble()/n
        return (out/3.5).coerceIn(-1.0,1.0)
    }
    @Synchronized fun noteOn(midi:Int) { freq=440.0*2.0.pow((midi-69)/12.0);gate=true }
    @Synchronized fun noteOff() { gate=false }
    fun preset(name:String) { brightness=when(name){"Soft Pad"->0.18f;"Bright Organ"->0.85f;else->0.45f} }
    fun render(seconds:Int):ByteArray {
        val count=sr*seconds
        val b=ByteBuffer.allocate(count*2).order(ByteOrder.LITTLE_ENDIAN)
        val old=gate;gate=true
        repeat(count) { val v=(sample()*12000).toInt().coerceIn(-32768,32767);b.putShort(v.toShort()) }
        gate=old
        return b.array()
    }
    fun stop() { playing=false;track?.pause();track?.flush();track?.release();track=null }
}
